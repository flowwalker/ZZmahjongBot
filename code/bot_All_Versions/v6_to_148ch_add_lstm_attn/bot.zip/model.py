import torch
from torch import nn
import torch.nn.functional as F
import numpy as np

def _safe_linear_forward(x, layer):
    """异常隔离与跨平台防护: 独立提取以供全网络安全调用"""
    try:
        return layer(x)
    except RuntimeError as e:
        if x.device.type == 'cpu' and 'primitive descriptor' in str(e):
            return F.linear(x, layer.weight, layer.bias)
        raise e

class SafeSelfAttention(nn.Module):
    """
    定制多头自注意力层
    内部强制使用 _safe_linear_forward，彻底规避 Botzone 沙盒 aarch64 环境下
    nn.MultiheadAttention 可能触发的 MKLDNN 崩溃问题。
    """
    def __init__(self, embed_dim, num_heads):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        assert self.head_dim * num_heads == self.embed_dim, "embed_dim must be divisible by num_heads"
        
        self.qkv_proj = nn.Linear(embed_dim, embed_dim * 3)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, x):
        B, N, C = x.size()
        
        # Safe Linear QKV
        qkv = _safe_linear_forward(x, self.qkv_proj)
        qkv = qkv.reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        # Scaled Dot-Product Attention
        attn_scores = (q @ k.transpose(-2, -1)) / np.sqrt(self.head_dim)
        attn_weights = F.softmax(attn_scores, dim=-1)
        
        attn_out = (attn_weights @ v).transpose(1, 2).reshape(B, N, C)
        
        # Safe Linear Output
        output = _safe_linear_forward(attn_out, self.out_proj)
        return output

class SEBlock(nn.Module):
    """通道注意力机制 (Squeeze-and-Excitation)"""
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.Mish(inplace=True), 
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = x.view(b, c, -1).mean(dim=2)
        y = _safe_linear_forward(y, self.fc[0])
        y = self.fc[1](y)
        y = _safe_linear_forward(y, self.fc[2])
        y = self.fc[3](y).view(b, c, 1, 1)
        return x * y

class ResidualBlock(nn.Module):
    """强化版残差块: Conv -> GN -> Mish -> Conv -> GN -> SE -> Add -> Mish"""
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.gn1 = nn.GroupNorm(16, channels)
        self.act = nn.Mish(inplace=True)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.gn2 = nn.GroupNorm(16, channels)
        self.se = SEBlock(channels)

    def forward(self, x):
        residual = x
        out = self.act(self.gn1(self.conv1(x)))
        out = self.gn2(self.conv2(out))
        out = self.se(out)
        out += residual
        return self.act(out)

class CNNModel(nn.Module):
    def __init__(self, in_channels=148, hidden_channels=256, num_res_blocks=16,
                 reduce_channels=128, fc_dim=1024):
        super().__init__()
        self.in_channels = in_channels

        # 1. 空间坐标注入 (CoordConv)
        grid_y, grid_x = torch.meshgrid(torch.arange(4), torch.arange(9), indexing='ij')
        grid_y = (grid_y.float() / 3.0) * 2.0 - 1.0
        grid_x = (grid_x.float() / 8.0) * 2.0 - 1.0
        self.register_buffer('coord_grid', torch.stack([grid_y, grid_x], dim=0).unsqueeze(0))

        # 2. 特征提炼干道 (Stem)
        self._conv_init = nn.Conv2d(in_channels + 2, hidden_channels, kernel_size=3, padding=1, bias=False)
        self._gn_init = nn.GroupNorm(16, hidden_channels)
        self._act = nn.Mish(inplace=True)

        # 3. 深度残差塔
        self._res_blocks = self._make_layer(ResidualBlock, hidden_channels, num_res_blocks)

        # 4. 降维过渡层
        self._conv_reduce = nn.Conv2d(hidden_channels, reduce_channels, kernel_size=1, bias=False)
        self._gn_reduce = nn.GroupNorm(8, reduce_channels)

        # 5. 时序动力核心 (Sequence Modeling: BiLSTM)
        self._lstm = nn.LSTM(
            input_size=reduce_channels,
            hidden_size=reduce_channels,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )

        # 6. 全局视野 (Self-Attention)
        lstm_out_dim = reduce_channels * 2  # Bidirectional
        self._attention = SafeSelfAttention(embed_dim=lstm_out_dim, num_heads=8)
        self._attn_norm = nn.LayerNorm(lstm_out_dim)

        self._flatten = nn.Flatten()

        # 计算打平后的特征总数: 序列长(36) * lstm_out_dim
        flat_dim = 36 * lstm_out_dim

        # 7. 双头输出层 (Policy & Value)
        self._logits = nn.Sequential(
            nn.Dropout(0.1),
            nn.Linear(flat_dim, fc_dim),
            nn.Mish(inplace=True),
            nn.Linear(fc_dim, 235)
        )

        self._value_branch = nn.ModuleList([
            nn.Dropout(0.1),
            nn.Linear(flat_dim, fc_dim),
            nn.Mish(inplace=True),
            nn.Linear(fc_dim, 1)
        ])

        # 初始化参数
        self._apply_orthogonal_init()

    def _make_layer(self, block, channels, num_blocks):
        """借鉴 ResNet 标准实现，生成深度网络"""
        layers = []
        for _ in range(num_blocks):
            layers.append(block(channels))
        return nn.Sequential(*layers)

    def _apply_orthogonal_init(self):
        """强化学习核心：全图正交初始化，稳定初始策略方差"""
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2))
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.GroupNorm):
                nn.init.constant_(module.weight, 1)
                nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.LSTM):
                for name, param in module.named_parameters():
                    if 'weight_ih' in name:
                        nn.init.orthogonal_(param, gain=np.sqrt(2))
                    elif 'weight_hh' in name:
                        nn.init.orthogonal_(param, gain=np.sqrt(2))
                    elif 'bias' in name:
                        nn.init.constant_(param, 0)

        # 策略头输出极小化，使初期动作概率近乎均匀
        if isinstance(self._logits[-1], nn.Linear):
            nn.init.orthogonal_(self._logits[-1].weight, gain=0.01)
            nn.init.constant_(self._logits[-1].bias, 0)

        if isinstance(self._value_branch[-1], nn.Linear):
            nn.init.orthogonal_(self._value_branch[-1].weight, gain=1.0)
            nn.init.constant_(self._value_branch[-1].bias, 0)

    def forward(self, input_dict: dict):
        obs = input_dict["observation"].float()
        batch_size = obs.size(0)
        
        # --- 阶段 1: 空间特征提炼 ---
        coords = self.coord_grid.expand(batch_size, -1, -1, -1)
        x = torch.cat([obs, coords], dim=1)

        x = self._act(self._gn_init(self._conv_init(x)))
        x = self._res_blocks(x)  # (B, 256, 4, 9)
        
        x = self._conv_reduce(x)
        x = self._gn_reduce(x)
        x = self._act(x)         # (B, 128, 4, 9)

        # --- 阶段 2: 序列与全局注意力建模 ---
        # 转换空间 -> 序列: (B, 128, 4*9) -> (B, 36, 128)
        b, c, h, w = x.size()
        seq_in = x.view(b, c, h * w).permute(0, 2, 1)
        
        # BiLSTM 时序提炼顺子及手牌延续性逻辑
        lstm_out, _ = self._lstm(seq_in) # (B, 36, 256)
        
        # Self-Attention 全局跨维度审视 (比如万字牌与字牌之间的取舍关联)
        attn_out = self._attention(lstm_out)
        
        # 残差连接 + LayerNorm 维持梯度健康
        seq_out = self._attn_norm(lstm_out + attn_out)
        seq_out = self._act(seq_out)
        
        # --- 阶段 3: 双头推理路由 ---
        flat_out = self._flatten(seq_out) # (B, 9216)

        # Safe Policy Route
        x_logits = flat_out
        for layer in self._logits:
            if isinstance(layer, nn.Linear):
                x_logits = _safe_linear_forward(x_logits, layer)
            else:
                x_logits = layer(x_logits)
        logits = x_logits

        # Masking 非法动作
        mask = input_dict["action_mask"].float()
        masked_logits = torch.where(
            mask > 0.5, 
            logits, 
            torch.tensor(-1e8, device=logits.device, dtype=logits.dtype)
        )

        # Safe Value Route
        v_hidden = flat_out
        for layer in self._value_branch:
            if isinstance(layer, nn.Linear):
                v_hidden = _safe_linear_forward(v_hidden, layer)
            else:
                v_hidden = layer(v_hidden)
        value = v_hidden

        return masked_logits, value

