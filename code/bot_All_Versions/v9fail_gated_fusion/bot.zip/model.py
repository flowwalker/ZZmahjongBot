"""
Vultra 模型 — 门控融合 vfinal(BiLSTM+Attn) + v5v6(纯卷积)
CNNModel 兼容接口
"""
from model_vultra import VultraModel

class CNNModel(VultraModel):
    pass
