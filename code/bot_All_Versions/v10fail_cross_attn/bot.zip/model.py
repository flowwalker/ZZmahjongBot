"""Monster-Lite 统一入口"""
from model_monster import MonsterModel

class CNNModel(MonsterModel):
    pass
