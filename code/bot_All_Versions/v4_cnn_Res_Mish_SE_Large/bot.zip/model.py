"""
国标麻将 AI 核心网络 — 终极演化版 (CoordConv + ResNet-SE + Orthogonal Init + Mish)
大模型配置: hidden=256, res_blocks=16, reduce=128, fc=1024 (~29M 参数)

保持完全一致的外部接口：
输入: input_dict['observation'] -> (batch, in_channels, 4, 9)
     input_dict['action_mask'] -> (batch, 235)
输出: masked_logits (batch, 235), value (batch, 1)
"""

import torch
from torch import nn
import torch.nn.functional as F
import numpy as np

def _safe_linear_forward(x, layer):
    """异常隔离与跨平台防护: 独立提取以供全网络安全调用"""
    try:
        return layer(x)
    except RuntimeError as e:
        if x.device.type == 'cpu' and 'primitive descriptor' in str(e):
            return F.linear(x, layer.weight, layer.bias)
        raise e

class SEBlock(nn.Module):
    """通道注意力机制 (Squeeze-and-Excitation)"""
    def __init__(self, channels, reduction=4):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.Mish(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = x.view(b, c, -1).mean(dim=2)
        y = _safe_linear_forward(y, self.fc[0])
        y = self.fc[1](y)
        y = _safe_linear_forward(y, self.fc[2])
        y = self.fc[3](y).view(b, c, 1, 1)
        return x * y

class ResidualBlock(nn.Module):
    """强化学习特化版残差块"""
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.gn1 = nn.GroupNorm(4, channels)
        self.act = nn.Mish(inplace=True)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.gn2 = nn.GroupNorm(4, channels)
        self.se = SEBlock(channels)

    def forward(self, x):
        residual = x
        out = self.act(self.gn1(self.conv1(x)))
        out = self.gn2(self.conv2(out))
        out = self.se(out)
        out += residual
        return self.act(out)

class CNNModel(nn.Module):
    def __init__(self, in_channels=16, hidden_channels=256, num_res_blocks=16,
                 reduce_channels=128, fc_dim=1024):
        super().__init__()
        self.in_channels = in_channels

        # CoordConv 坐标系 Buffer
        grid_y, grid_x = torch.meshgrid(torch.arange(4), torch.arange(9), indexing='ij')
        grid_y = (grid_y.float() / 3.0) * 2.0 - 1.0
        grid_x = (grid_x.float() / 8.0) * 2.0 - 1.0
        self.register_buffer('coord_grid', torch.stack([grid_y, grid_x], dim=0).unsqueeze(0))

        # 初始卷积 (CoordConv)
        self._conv_init = nn.Conv2d(in_channels + 2, hidden_channels, kernel_size=3, padding=1, bias=False)
        self._gn_init = nn.GroupNorm(4, hidden_channels)
        self._act = nn.Mish(inplace=True)

        # 残差块堆 (16 x ResBlock@256ch)
        self._res_blocks = nn.Sequential(
            *[ResidualBlock(hidden_channels) for _ in range(num_res_blocks)]
        )

        # 降维卷积 (1x1)
        self._conv_reduce = nn.Conv2d(hidden_channels, reduce_channels, kernel_size=1, bias=False)
        self._gn_reduce = nn.GroupNorm(4, reduce_channels)
        self._flatten = nn.Flatten()

        # Policy Head
        self._logits = nn.Sequential(
            nn.Linear(reduce_channels * 4 * 9, fc_dim),
            nn.Mish(inplace=True),
            nn.Linear(fc_dim, 235)
        )

        # Value Head
        self._value_branch = nn.ModuleList([
            nn.Linear(reduce_channels * 4 * 9, fc_dim),
            nn.Mish(inplace=True),
            nn.Linear(fc_dim, 1)
        ])

        self._apply_orthogonal_init()

    def _apply_orthogonal_init(self):
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.orthogonal_(module.weight, gain=np.sqrt(2))
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.GroupNorm):
                nn.init.constant_(module.weight, 1)
                nn.init.constant_(module.bias, 0)

        nn.init.orthogonal_(self._logits[-1].weight, gain=0.01)
        nn.init.constant_(self._logits[-1].bias, 0)

        nn.init.orthogonal_(self._value_branch[-1].weight, gain=1.0)
        nn.init.constant_(self._value_branch[-1].bias, 0)

    def forward(self, input_dict: dict):
        obs = input_dict["observation"].float()
        batch_size = obs.size(0)

        coords = self.coord_grid.expand(batch_size, -1, -1, -1)
        obs_with_coords = torch.cat([obs, coords], dim=1)

        hidden = self._conv_init(obs_with_coords)
        hidden = self._gn_init(hidden)
        hidden = self._act(hidden)
        hidden = self._res_blocks(hidden)

        hidden = self._conv_reduce(hidden)
        hidden = self._gn_reduce(hidden)
        hidden = self._act(hidden)
        hidden = self._flatten(hidden)

        x_logits = hidden
        for layer in self._logits:
            if isinstance(layer, nn.Linear):
                x_logits = _safe_linear_forward(x_logits, layer)
            else:
                x_logits = layer(x_logits)
        logits = x_logits

        mask = input_dict["action_mask"].float()
        masked_logits = torch.where(
            mask > 0.5,
            logits,
            torch.tensor(-1e8, device=logits.device, dtype=logits.dtype)
        )

        v_hidden = _safe_linear_forward(hidden, self._value_branch[0])
        v_hidden = self._value_branch[1](v_hidden)
        value = _safe_linear_forward(v_hidden, self._value_branch[2])

        return masked_logits, value
